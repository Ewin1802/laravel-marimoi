<?php

namespace App\Http\Controllers;

use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class SettingController extends Controller
{
    /**
     * Tampilkan form pengaturan website.
     *
     * Settings bersifat singleton (hanya 1 baris data),
     * jadi tidak ada index/create/destroy — hanya edit & update.
     */
    public function edit()
    {
        $setting = Setting::first() ?? new Setting();

        return view('pages.setting.edit', compact('setting'));
    }

    /**
     * Simpan perubahan pengaturan website.
     */
    public function update(Request $request)
    {
        $validated = $request->validate([
            // Informasi Toko
            'store_name'         => ['required', 'string', 'max:255'],
            'store_tagline'      => ['nullable', 'string', 'max:255'],
            'store_description'  => ['nullable', 'string'],

            // Logo
            'logo'    => ['nullable', 'image', 'max:2048'],
            'favicon' => ['nullable', 'image', 'max:1024'],

            // Hero Landing Page
            'hero_title'    => ['nullable', 'string', 'max:255'],
            'hero_subtitle' => ['nullable', 'string'],
            'hero_button'   => ['nullable', 'string', 'max:100'],

            // Kontak
            'phone'       => ['nullable', 'string', 'max:30'],
            'whatsapp'    => ['nullable', 'string', 'max:30'],
            'email'       => ['nullable', 'email', 'max:255'],
            'address'     => ['nullable', 'string'],
            'google_maps' => ['nullable', 'string'],

            // Social Media
            'facebook'  => ['nullable', 'url', 'max:255'],
            'instagram' => ['nullable', 'url', 'max:255'],
            'youtube'   => ['nullable', 'url', 'max:255'],
            'tiktok'    => ['nullable', 'url', 'max:255'],

            // SEO
            'meta_title'       => ['nullable', 'string', 'max:255'],
            'meta_description' => ['nullable', 'string'],
            'meta_keywords'    => ['nullable', 'string', 'max:255'],

            // Footer
            'copyright' => ['nullable', 'string', 'max:255'],

            // Status Website
            'maintenance_mode' => ['nullable', 'boolean'],
        ]);

        $setting = Setting::first() ?? new Setting();

        // =====================================================
        // UPLOAD LOGO
        // =====================================================
        if ($request->hasFile('logo')) {
            if ($setting->logo) {
                Storage::disk('public')->delete($setting->logo);
            }

            $validated['logo'] = $request->file('logo')->store('settings', 'public');
        } else {
            unset($validated['logo']);
        }

        // =====================================================
        // UPLOAD FAVICON
        // =====================================================
        if ($request->hasFile('favicon')) {
            if ($setting->favicon) {
                Storage::disk('public')->delete($setting->favicon);
            }

            $validated['favicon'] = $request->file('favicon')->store('settings', 'public');
        } else {
            unset($validated['favicon']);
        }

        $validated['maintenance_mode'] = $request->boolean('maintenance_mode');

        $setting->fill($validated);
        $setting->save();

        return redirect()
            ->route('settings.edit')
            ->with('success', 'Pengaturan berhasil diperbarui.');
    }
}
